#include <iostream>
using namespace std;
int main()
{
        cout << "Merhaba ROS" << endl;
        return 0;
}
