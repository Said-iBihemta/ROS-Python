from ._GecenZaman import *
