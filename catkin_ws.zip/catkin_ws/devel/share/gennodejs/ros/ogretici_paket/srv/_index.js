
"use strict";

let GecenZaman = require('./GecenZaman.js')

module.exports = {
  GecenZaman: GecenZaman,
};
