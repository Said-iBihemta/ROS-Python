
"use strict";

let BataryaDurum = require('./BataryaDurum.js');
let GorevDurumActionGoal = require('./GorevDurumActionGoal.js');
let GorevDurumGoal = require('./GorevDurumGoal.js');
let GorevDurumFeedback = require('./GorevDurumFeedback.js');
let GorevDurumAction = require('./GorevDurumAction.js');
let GorevDurumActionFeedback = require('./GorevDurumActionFeedback.js');
let GorevDurumResult = require('./GorevDurumResult.js');
let GorevDurumActionResult = require('./GorevDurumActionResult.js');

module.exports = {
  BataryaDurum: BataryaDurum,
  GorevDurumActionGoal: GorevDurumActionGoal,
  GorevDurumGoal: GorevDurumGoal,
  GorevDurumFeedback: GorevDurumFeedback,
  GorevDurumAction: GorevDurumAction,
  GorevDurumActionFeedback: GorevDurumActionFeedback,
  GorevDurumResult: GorevDurumResult,
  GorevDurumActionResult: GorevDurumActionResult,
};
